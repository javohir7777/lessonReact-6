const StudentSearch = () => {
  return <div>StudentSearch</div>;
};

export default StudentSearch;
